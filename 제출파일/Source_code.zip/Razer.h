#pragma once

void make_razer(GLfloat tz, GLfloat size, GLfloat tx);
void razer_setTransform(int idx);