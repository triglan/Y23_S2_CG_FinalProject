#pragma once

void make_razerLauncher(GLfloat tz, GLfloat size, GLfloat tx);
void razerLauncher_setTransform(int idx);