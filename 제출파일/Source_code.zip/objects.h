#pragma once
#include "config.h"

void make_cannon(GLfloat tz, GLfloat size, GLfloat angle);
void cannon_setTransform(int idx);