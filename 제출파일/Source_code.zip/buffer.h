﻿// 버퍼 초기화
#ifndef MODEL_BUFFER_H
#define MODEL_BUFFER_H
#include "config.h"

void setBuffer(int idx, int bufferMode);
void vertexInput(int idx);

#endif
